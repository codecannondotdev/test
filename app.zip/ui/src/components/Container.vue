<template>
	<div class="container">
		<slot></slot>
	</div>
</template>

<style scoped lang="scss">
.container {
	width: 100%;
	max-width: 1700px;
	padding: 24px 32px;
}
</style>
